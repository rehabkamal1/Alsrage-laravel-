<?php

namespace App\Http\Requests;

use App\Models\OrderTracking;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateOrderTrackingRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'workflow_status' => ['sometimes', 'nullable', 'string', Rule::in(OrderTracking::WORKFLOW_STATUSES)],
            'external_office_id' => ['nullable', 'exists:external_offices,id'],
            'saudi_office_id' => ['nullable', 'exists:saudi_offices,id'],
            'is_authenticated' => ['sometimes', 'boolean'],
            'authentication_date' => ['nullable', 'date'],
            'certification_date' => ['nullable', 'date'],
            'authentication_number' => ['nullable', 'string', 'max:100'],
            'authorization_number' => ['nullable', 'string', 'max:100'],
            'sponsor_number' => ['nullable', 'string', 'max:100'],
            'delegate_phone' => ['nullable', 'string', 'max:100'],
            'last_action_date' => ['nullable', 'date'],
            'notes' => ['nullable', 'string'],
            'priority_level' => ['nullable', 'string'],
            'passport_status' => ['nullable', 'string'],
            'transfer_status' => ['nullable', 'string'],
            'authentication_status' => ['nullable', 'string'],
            'authorization_status' => ['nullable', 'string'],
        ];
    }
}

<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Support\PermissionAccess;
use Illuminate\Http\Request;
use Carbon\Carbon;

class ReportController extends Controller
{
    public function orderFollowUp(Request $request)
    {
        $query = Order::with(['client', 'employee', 'tracking', 'saudiOffice', 'externalOffice']);

        // Filters
        if ($request->filled('date_from')) {
            $query->whereDate('created_at', '>=', $request->date_from);
        }
        if ($request->filled('date_to')) {
            $query->whereDate('created_at', '<=', $request->date_to);
        }
        if ($request->filled('employee_id')) {
            $query->where('employee_id', $request->employee_id);
        } elseif ($request->filled('marketer_id')) {
            $query->where('employee_id', $request->marketer_id);
        }
        if ($request->filled('saudi_office_id')) {
            $query->where('saudi_office_id', $request->saudi_office_id);
        }
        if ($request->filled('external_office_id')) {
            $query->where('external_office_id', $request->external_office_id);
        }
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        } else {
            // Only active orders for follow up when no specific status is selected
            $query->whereNotIn('status', ['completed', 'cancelled', 'مكتمل', 'ملغي']);
        }
        // Parse multi-select authentication status filter
        $authStatusesFilter = [];
        if ($request->filled('authentication_statuses')) {
            $authStatusesFilter = is_array($request->authentication_statuses) 
                ? $request->authentication_statuses 
                : array_filter(explode(',', $request->authentication_statuses));
        } elseif ($request->filled('authentication_status')) {
            $authStatusesFilter = is_array($request->authentication_status) 
                ? $request->authentication_status 
                : array_filter(explode(',', $request->authentication_status));
        }

        if (!empty($authStatusesFilter)) {
            $allAuthSettings = \App\Models\Setting::where('group', 'authentication_status')->get();
            $resolvedAuthValues = [];
            foreach ($authStatusesFilter as $asVal) {
                $resolvedAuthValues[] = $asVal;
                $stObj = $allAuthSettings->first(function ($item) use ($asVal) {
                    return $item->key === $asVal || $item->label === $asVal;
                });
                if ($stObj) {
                    if (!empty($stObj->key)) $resolvedAuthValues[] = $stObj->key;
                    if (!empty($stObj->label)) $resolvedAuthValues[] = $stObj->label;
                }
            }
            $resolvedAuthValues = array_values(array_unique(array_filter($resolvedAuthValues)));

            $query->whereHas('tracking', function ($q) use ($resolvedAuthValues) {
                $q->whereIn('authentication_status', $resolvedAuthValues);
            });
        }

        $orders = $query->get();

        // Load dynamic target SLA days and labels for each stage/status from settings
        $statusSettings = \App\Models\Setting::where('group', 'order_status')->get();
        $statusSettingsMap = $statusSettings
            ->mapWithKeys(function ($item) {
                return [$item->key => (int) ($item->target_days ?: 60)];
            })
            ->toArray();
        $statusLabelMap = $statusSettings
            ->mapWithKeys(function ($item) {
                return [$item->key => $item->label];
            })
            ->toArray();

        $authSettings = \App\Models\Setting::where('group', 'authentication_status')->get();
        $authLabelMap = $authSettings
            ->mapWithKeys(function ($item) {
                return [$item->key => $item->label];
            })
            ->toArray();
        $authColorMap = $authSettings
            ->mapWithKeys(function ($item) {
                return [$item->key => $item->color ?: '#0284c7', $item->label => $item->color ?: '#0284c7'];
            })
            ->toArray();

        $now = Carbon::now();

        $totalLate = 0;
        $withoutFollowup = 0;
        $exceededSla = 0;
        $totalDelayDays = 0;

        $processedOrders = $orders->map(function ($order) use ($statusSettingsMap, $statusLabelMap, $authLabelMap, $authColorMap, $now, &$totalLate, &$withoutFollowup, &$exceededSla, &$totalDelayDays) {
            $startDate = $order->contract_date ? Carbon::parse($order->contract_date) : $order->created_at;
            $daysSinceStart = (int) $startDate->diffInDays($now);
            
            // Get stage SLA target days from settings (default to 60 if not configured)
            $stageTargetDays = (int) ($statusSettingsMap[$order->status] ?? 60);
            $delayDays = max(0, $daysSinceStart - $stageTargetDays);
            
            $isLate = $delayDays > 0;
            $isWithoutFollowup = !$order->tracking || !$order->tracking->last_action_date;
            
            if ($isLate) {
                $totalLate++;
                $exceededSla++;
                $totalDelayDays += $delayDays;
            }
            if ($isWithoutFollowup) {
                $withoutFollowup++;
            }

            $statusLabel = $statusLabelMap[$order->status] ?? $order->status;
            $rawAuth = $order->tracking ? $order->tracking->authentication_status : null;
            $authLabel = $rawAuth ? ($authLabelMap[$rawAuth] ?? $rawAuth) : null;
            $authColor = $rawAuth ? ($authColorMap[$rawAuth] ?? ($authColorMap[$authLabel] ?? '#0284c7')) : null;

            return [
                'id' => $order->id,
                'order_number' => $order->id, // fallback if there is no order_number field
                'visa_number' => $order->visa_number ?: '-',
                'client' => ['name' => $order->client ? $order->client->name : '-'],
                'client_name' => $order->client ? $order->client->name : '-',
                'employee' => ['name' => $order->employee ? $order->employee->name : '-'],
                'employee_name' => $order->employee ? $order->employee->name : '-',
                'saudi_office' => $order->saudiOffice ? $order->saudiOffice->name : '-',
                'external_office' => $order->externalOffice ? $order->externalOffice->name : '-',
                'status' => [
                    'name' => $statusLabel ?: 'غير محدد',
                    'key' => $order->status,
                ],
                'status_name' => $statusLabel ?: 'غير محدد',
                'raw_status' => $order->status,
                'authentication_status' => $authLabel,
                'raw_authentication_status' => $rawAuth,
                'authentication_status_color' => $authColor,
                'last_update_date' => $order->tracking && $order->tracking->last_action_date ? $order->tracking->last_action_date->format('Y-m-d') : '-',
                'delay_days' => $delayDays,
                'exceeded_sla' => $isLate,
                'is_without_followup' => $isWithoutFollowup,
                'contract_date' => $order->contract_date ? Carbon::parse($order->contract_date)->format('Y-m-d') : ($order->created_at ? $order->created_at->format('Y-m-d') : '-'),
            ];
        });

        $avgDelayDays = $totalLate > 0 ? round($totalDelayDays / $totalLate, 1) : 0;
        $totalOrders = $orders->count();
        $withinSla = max(0, $totalOrders - $exceededSla);

        // Count authentication statuses across all orders in the report
        $authCountsMap = [];
        foreach ($processedOrders as $po) {
            $al = $po['authentication_status'];
            if ($al && $al !== '-') {
                $authCountsMap[$al] = ($authCountsMap[$al] ?? 0) + 1;
            }
        }
        $authStatusesList = [];
        foreach ($authSettings as $ast) {
            $authStatusesList[] = [
                'key' => $ast->key,
                'label' => $ast->label,
                'color' => $ast->color ?: '#0284c7',
                'count' => $authCountsMap[$ast->label] ?? ($authCountsMap[$ast->key] ?? 0),
            ];
        }

        return response()->json([
            'kpis' => [
                'total_orders' => $totalOrders,
                'total_late' => $totalLate,
                'without_followup' => $withoutFollowup,
                'exceeded_sla' => $exceededSla,
                'within_sla' => $withinSla,
                'avg_delay_days' => $avgDelayDays,
            ],
            'orders' => $processedOrders,
            'authentication_statuses' => $authStatusesList,
        ]);
    }

    public function completedOrders(Request $request)
    {
        $query = Order::with(['client', 'employee', 'saudiOffice', 'externalOffice'])
            ->whereIn('status', ['completed', 'مكتمل']);

        // Filters
        if ($request->filled('date_from')) {
            $query->whereDate('updated_at', '>=', $request->date_from);
        }
        if ($request->filled('date_to')) {
            $query->whereDate('updated_at', '<=', $request->date_to);
        }
        if ($request->filled('employee_id')) {
            $query->where('employee_id', $request->employee_id);
        } elseif ($request->filled('marketer_id')) {
            $query->where('employee_id', $request->marketer_id);
        }
        if ($request->filled('client_id')) {
            $query->where('client_id', $request->client_id);
        }
        if ($request->filled('saudi_office_id')) {
            $query->where('saudi_office_id', $request->saudi_office_id);
        }
        if ($request->filled('external_office_id')) {
            $query->where('external_office_id', $request->external_office_id);
        }

        $orders = $query->latest('updated_at')->get();

        $SLA_DAYS = 60;
        $totalCompleted = $orders->count();
        $totalRevenue = 0;
        $totalCompletionDays = 0;
        $withinSlaCount = 0;

        $processedOrders = $orders->map(function ($order) use ($SLA_DAYS, &$totalRevenue, &$totalCompletionDays, &$withinSlaCount) {
            $startDate = $order->contract_date ? Carbon::parse($order->contract_date) : $order->created_at;
            $completedDate = $order->updated_at;
            $completionDays = max(1, $startDate->diffInDays($completedDate));

            $totalRevenue += (float) ($order->total_price ?? 0);
            $totalCompletionDays += $completionDays;

            if ($completionDays <= $SLA_DAYS) {
                $withinSlaCount++;
            }

            return [
                'id' => $order->id,
                'visa_number' => $order->visa_number ?: "-",
                'client_name' => $order->client ? $order->client->name : ($order->visa_holder_name ?: "-"),
                'employee_name' => $order->employee ? $order->employee->name : "-",
                'saudi_office' => $order->saudiOffice ? $order->saudiOffice->name : "-",
                'external_office' => $order->externalOffice ? $order->externalOffice->name : "-",
                'service_type' => $order->service_type ?: "-",
                'total_price' => (float) ($order->total_price ?? 0),
                'completion_days' => $completionDays,
                'completed_at' => $completedDate ? $completedDate->format('Y-m-d') : "-",
                'within_sla' => $completionDays <= $SLA_DAYS,
            ];
        });

        $avgCompletionDays = $totalCompleted > 0 ? round($totalCompletionDays / $totalCompleted, 1) : 0;
        $slaComplianceRate = $totalCompleted > 0 ? round(($withinSlaCount / $totalCompleted) * 100, 1) : 100;

        return response()->json([
            'kpis' => [
                'total_completed' => $totalCompleted,
                'total_revenue' => $totalRevenue,
                'avg_completion_days' => $avgCompletionDays,
                'sla_compliance_rate' => $slaComplianceRate,
            ],
            'orders' => $processedOrders,
        ]);
    }

    public function officesPerformance(Request $request)
    {
        $dateFrom = $request->date_from;
        $dateTo = $request->date_to;
        $country = $request->country;
        $city = $request->city;
        $saudiOfficeId = $request->saudi_office_id;
        $externalOfficeId = $request->external_office_id;

        // Parse multi-status filter (comma separated string or array)
        $statusesFilter = [];
        if ($request->filled('statuses')) {
            $statusesFilter = is_array($request->statuses) ? $request->statuses : array_filter(explode(',', $request->statuses));
        } elseif ($request->filled('status')) {
            $statusesFilter = is_array($request->status) ? $request->status : array_filter(explode(',', $request->status));
        }

        // Parse authentication status filter (comma separated string or array)
        $authStatusesFilter = [];
        if ($request->filled('authentication_status')) {
            $authStatusesFilter = is_array($request->authentication_status) ? $request->authentication_status : array_filter(explode(',', $request->authentication_status));
        } elseif ($request->filled('authentication_statuses')) {
            $authStatusesFilter = is_array($request->authentication_statuses) ? $request->authentication_statuses : array_filter(explode(',', $request->authentication_statuses));
        }

        $resolvedAuthValues = [];
        if (!empty($authStatusesFilter)) {
            $authSettingsAll = \App\Models\Setting::where('group', 'authentication_status')->get();
            foreach ($authStatusesFilter as $asVal) {
                $resolvedAuthValues[] = $asVal;
                $stObj = $authSettingsAll->first(function ($item) use ($asVal) {
                    return $item->key === $asVal || $item->label === $asVal;
                });
                if ($stObj) {
                    if (!empty($stObj->key)) $resolvedAuthValues[] = $stObj->key;
                    if (!empty($stObj->label)) $resolvedAuthValues[] = $stObj->label;
                }
            }
            $resolvedAuthValues = array_values(array_unique(array_filter($resolvedAuthValues)));
        }

        // Retrieve configured order statuses from settings to map colors & labels
        $configuredStatuses = \App\Models\Setting::where('group', 'order_status')
            ->orderBy('sort_order')
            ->get(['key', 'label', 'color']);

        $statusColorMap = [];
        $statusLabelMap = [];

        foreach ($configuredStatuses as $st) {
            $statusColorMap[$st->key] = $st->color ?: '#6c757d';
            $statusColorMap[$st->label] = $st->color ?: '#6c757d';
            $statusLabelMap[$st->key] = $st->label;
            $statusLabelMap[$st->label] = $st->label;
        }

        // Retrieve configured authentication statuses from settings
        $configuredAuthStatuses = \App\Models\Setting::where('group', 'authentication_status')
            ->orderBy('sort_order')
            ->get(['key', 'label', 'color']);

        $authStatusColorMap = [];
        $authStatusLabelMap = [];
        foreach ($configuredAuthStatuses as $ast) {
            $authStatusColorMap[$ast->key] = $ast->color ?: '#0284c7';
            $authStatusColorMap[$ast->label] = $ast->color ?: '#0284c7';
            $authStatusLabelMap[$ast->key] = $ast->label;
            $authStatusLabelMap[$ast->label] = $ast->label;
        }

        // Fetch distinct available countries and cities for filters
        $countries = \App\Models\ExternalOffice::whereNotNull('country')
            ->where('country', '!=', '')
            ->distinct()
            ->pluck('country')
            ->values();

        $cities = \App\Models\SaudiOffice::whereNotNull('city')
            ->where('city', '!=', '')
            ->distinct()
            ->pluck('city')
            ->values();

        // Accumulator for overall status counts across all offices
        $globalStatusCounts = [];
        $globalAuthStatusCounts = [];

        $processOfficeOrders = function ($officeQuery, $isSaudi = true) use ($dateFrom, $dateTo, $saudiOfficeId, $externalOfficeId, $statusesFilter, $statusColorMap, $statusLabelMap, $resolvedAuthValues, $authStatusColorMap, $authStatusLabelMap, &$globalStatusCounts, &$globalAuthStatusCounts) {
            return $officeQuery->get()->map(function ($office) use ($isSaudi, $dateFrom, $dateTo, $saudiOfficeId, $externalOfficeId, $statusesFilter, $statusColorMap, $statusLabelMap, $resolvedAuthValues, $authStatusColorMap, $authStatusLabelMap, &$globalStatusCounts, &$globalAuthStatusCounts) {
                $ordersQuery = $office->orders()->with(['client', 'employee', 'tracking']);

                if (!empty($dateFrom)) {
                    $ordersQuery->whereDate('created_at', '>=', $dateFrom);
                }
                if (!empty($dateTo)) {
                    $ordersQuery->whereDate('created_at', '<=', $dateTo);
                }
                if ($isSaudi && !empty($externalOfficeId)) {
                    $ordersQuery->where('external_office_id', $externalOfficeId);
                }
                if (!$isSaudi && !empty($saudiOfficeId)) {
                    $ordersQuery->where('saudi_office_id', $saudiOfficeId);
                }
                if (!empty($resolvedAuthValues)) {
                    $ordersQuery->whereHas('tracking', function ($q) use ($resolvedAuthValues) {
                        $q->whereIn('authentication_status', $resolvedAuthValues);
                    });
                }
                if (!empty($statusesFilter)) {
                    $ordersQuery->where(function($q) use ($statusesFilter) {
                        foreach (array_values($statusesFilter) as $idx => $stVal) {
                            $method = $idx === 0 ? 'where' : 'orWhere';
                            $q->$method(function($subQ) use ($stVal) {
                                $subQ->where('status', $stVal);
                                if ($stVal === 'completed' || $stVal === 'مكتمل') {
                                    $subQ->orWhereIn('status', ['completed', 'مكتمل']);
                                } elseif ($stVal === 'processing' || $stVal === 'قيد التنفيذ') {
                                    $subQ->orWhereIn('status', ['processing', 'قيد التنفيذ']);
                                } elseif ($stVal === 'pending' || $stVal === 'قيد الانتظار') {
                                    $subQ->orWhereIn('status', ['pending', 'قيد الانتظار']);
                                } elseif ($stVal === 'canceled' || $stVal === 'cancelled' || $stVal === 'ملغي') {
                                    $subQ->orWhereIn('status', ['canceled', 'cancelled', 'ملغي']);
                                }
                            });
                        }
                    });
                }

                $orders = $ordersQuery->get();

                $totalOrders = $orders->count();
                $completedOrders = $orders->filter(fn($o) => in_array($o->status, ['completed', 'مكتمل']))->count();
                $inProgressOrders = $orders->filter(fn($o) => !in_array($o->status, ['completed', 'cancelled', 'canceled', 'مكتمل', 'ملغي']))->count();
                $cancelledOrders = $orders->filter(fn($o) => in_array($o->status, ['cancelled', 'canceled', 'ملغي']))->count();

                $totalRevenue = (float) $orders->sum('total_price');
                $completionRate = $totalOrders > 0 ? round(($completedOrders / $totalOrders) * 100, 1) : 0;

                // Status breakdown per office
                $statusCountsMap = [];

                $ordersDetails = $orders->map(function ($order) use ($statusColorMap, $statusLabelMap, $authStatusColorMap, $authStatusLabelMap, &$statusCountsMap, &$globalStatusCounts, &$globalAuthStatusCounts) {
                    $rawStatus = $order->status ?: 'غير محدد';
                    $statusLabel = $statusLabelMap[$rawStatus] ?? $rawStatus;
                    $statusColor = $statusColorMap[$rawStatus] ?? ($statusColorMap[$statusLabel] ?? '#6c757d');

                    $rawAuth = $order->tracking ? $order->tracking->authentication_status : null;
                    $authLabel = $rawAuth ? ($authStatusLabelMap[$rawAuth] ?? $rawAuth) : '-';
                    $authColor = $rawAuth ? ($authStatusColorMap[$rawAuth] ?? ($authStatusColorMap[$authLabel] ?? '#0284c7')) : '#6c757d';

                    if (!isset($statusCountsMap[$statusLabel])) {
                        $statusCountsMap[$statusLabel] = [
                            'key' => $rawStatus,
                            'label' => $statusLabel,
                            'color' => $statusColor,
                            'count' => 0
                        ];
                    }
                    $statusCountsMap[$statusLabel]['count']++;

                    if (!isset($globalStatusCounts[$statusLabel])) {
                        $globalStatusCounts[$statusLabel] = [
                            'key' => $rawStatus,
                            'label' => $statusLabel,
                            'color' => $statusColor,
                            'count' => 0
                        ];
                    }
                    $globalStatusCounts[$statusLabel]['count']++;

                    if ($authLabel && $authLabel !== '-') {
                        if (!isset($globalAuthStatusCounts[$authLabel])) {
                            $globalAuthStatusCounts[$authLabel] = [
                                'key' => $rawAuth,
                                'label' => $authLabel,
                                'color' => $authColor,
                                'count' => 0
                            ];
                        }
                        $globalAuthStatusCounts[$authLabel]['count']++;
                    }

                    return [
                        'id' => $order->id,
                        'visa_number' => $order->visa_number ?: '-',
                        'client_name' => $order->client ? $order->client->name : ($order->visa_holder_name ?: '-'),
                        'employee_name' => $order->employee ? $order->employee->name : '-',
                        'service_type' => $order->service_type ?: '-',
                        'total_price' => (float) ($order->total_price ?? 0),
                        'status' => $statusLabel,
                        'status_raw' => $rawStatus,
                        'status_color' => $statusColor,
                        'authentication_status' => $authLabel,
                        'authentication_status_raw' => $rawAuth,
                        'authentication_status_color' => $authColor,
                        'contract_date' => $order->contract_date ? Carbon::parse($order->contract_date)->format('Y-m-d') : ($order->created_at ? $order->created_at->format('Y-m-d') : '-'),
                    ];
                })->values();

                return [
                    'id' => $office->id,
                    'name' => $office->name,
                    'city' => $office->city ?: '-',
                    'country' => $office->country ?: '-',
                    'phone' => $office->phone ?: '-',
                    'total_orders' => $totalOrders,
                    'completed_orders' => $completedOrders,
                    'in_progress_orders' => $inProgressOrders,
                    'cancelled_orders' => $cancelledOrders,
                    'status_counts' => array_values($statusCountsMap),
                    'total_revenue' => $totalRevenue,
                    'completion_rate' => $completionRate,
                    'orders_details' => $ordersDetails,
                ];
            });
        };

        // 1. Process Saudi Offices
        $saudiQuery = \App\Models\SaudiOffice::query();
        if (!empty($city)) {
            $saudiQuery->where('city', $city);
        }
        if (!empty($saudiOfficeId)) {
            $saudiQuery->where('id', $saudiOfficeId);
        }
        if (!empty($externalOfficeId)) {
            $saudiQuery->whereHas('orders', function ($q) use ($externalOfficeId) {
                $q->where('external_office_id', $externalOfficeId);
            });
        }
        $saudiOffices = $processOfficeOrders($saudiQuery, true);

        // 2. Process External Offices
        $externalQuery = \App\Models\ExternalOffice::query();
        if (!empty($country)) {
            $externalQuery->where('country', $country);
        }
        if (!empty($externalOfficeId)) {
            $externalQuery->where('id', $externalOfficeId);
        }
        if (!empty($saudiOfficeId)) {
            $externalQuery->whereHas('orders', function ($q) use ($saudiOfficeId) {
                $q->where('saudi_office_id', $saudiOfficeId);
            });
        }
        $externalOffices = $processOfficeOrders($externalQuery, false);

        // Summary KPIs
        $totalSaudiOrders = $saudiOffices->sum('total_orders');
        $totalExternalOrders = $externalOffices->sum('total_orders');
        $totalSaudiRevenue = $saudiOffices->sum('total_revenue');
        $totalExternalRevenue = $externalOffices->sum('total_revenue');

        // Available statuses list (settings + any actual found statuses)
        $statusesList = [];
        foreach ($configuredStatuses as $st) {
            $label = $st->label;
            $statusesList[$label] = [
                'key' => $st->key,
                'label' => $st->label,
                'color' => $st->color ?: '#6c757d',
                'count' => $globalStatusCounts[$label]['count'] ?? 0,
            ];
        }

        // Add any found status in globalStatusCounts that was not in settings
        foreach ($globalStatusCounts as $label => $stInfo) {
            if (!isset($statusesList[$label])) {
                $statusesList[$label] = $stInfo;
            }
        }

        // Available authentication statuses list (settings + counts)
        $authStatusesList = [];
        foreach ($configuredAuthStatuses as $ast) {
            $label = $ast->label;
            $authStatusesList[$label] = [
                'key' => $ast->key,
                'label' => $ast->label,
                'color' => $ast->color ?: '#0284c7',
                'count' => $globalAuthStatusCounts[$label]['count'] ?? ($globalAuthStatusCounts[$ast->key]['count'] ?? 0),
            ];
        }
        foreach ($globalAuthStatusCounts as $label => $astInfo) {
            if (!isset($authStatusesList[$label])) {
                $authStatusesList[$label] = $astInfo;
            }
        }

        return response()->json([
            'kpis' => [
                'total_saudi_offices' => $saudiOffices->count(),
                'total_external_offices' => $externalOffices->count(),
                'total_saudi_orders' => $totalSaudiOrders,
                'total_external_orders' => $totalExternalOrders,
                'total_saudi_revenue' => $totalSaudiRevenue,
                'total_external_revenue' => $totalExternalRevenue,
                'grand_total_orders' => $totalSaudiOrders + $totalExternalOrders,
                'grand_total_revenue' => $totalSaudiRevenue + $totalExternalRevenue,
                'status_counts' => array_values($globalStatusCounts),
            ],
            'statuses' => array_values($statusesList),
            'authentication_statuses' => array_values($authStatusesList),
            'countries' => $countries,
            'cities' => $cities,
            'saudi_offices' => $saudiOffices,
            'external_offices' => $externalOffices,
        ]);
    }

    public function financialCollections(Request $request)
    {
        Order::checkAwaitingMusanedTransferTimeouts();
        $hideDelegateNumbers = PermissionAccess::isHiddenFor($request->user(), PermissionAccess::HIDE_DELEGATE_NUMBERS);

        $query = Order::with(['client', 'employee.saudiOffice', 'saudiOffice', 'externalOffice', 'transactions']);

        if ($request->filled('date_from')) {
            $query->whereDate('created_at', '>=', $request->date_from);
        }
        if ($request->filled('date_to')) {
            $query->whereDate('created_at', '<=', $request->date_to);
        }
        if ($request->filled('saudi_office_id')) {
            $query->where('saudi_office_id', $request->saudi_office_id);
        }
        if ($request->filled('client_id')) {
            $query->where('client_id', $request->client_id);
        }
        if ($request->filled('employee_id')) {
            $query->where('employee_id', $request->employee_id);
        } elseif ($request->filled('marketer_id')) {
            $query->where('employee_id', $request->marketer_id);
        }

        // Contract & Payment Status filter (Default: only 'تم السداد مساند' as requested in Point 3)
        $contractStatus = $request->input('contract_status', 'musaned_paid');
        if ($contractStatus === 'musaned_paid') {
            $query->where(function($q) {
                $q->where('status', 'تم السداد مساند')
                  ->orWhere('status', 'musaned_paid')
                  ->orWhere('musaned_paid', '>', 0);
            });
        } elseif ($contractStatus === 'active') {
            $query->whereNotIn('status', ['completed', 'cancelled', 'canceled', 'مكتمل', 'ملغي']);
        } elseif ($contractStatus === 'completed') {
            $query->whereIn('status', ['completed', 'مكتمل']);
        } elseif ($contractStatus === 'cancelled') {
            $query->whereIn('status', ['cancelled', 'canceled', 'ملغي']);
        } elseif ($contractStatus === 'awaiting_transfer') {
            $query->whereIn('status', ['تم انتظار حوالة مساند', 'بانتظار حوالة مساند', 'awaiting_musaned_transfer']);
        } elseif ($contractStatus === 'not_paid') {
            $query->whereIn('status', ['لم يتم السداد', 'not_paid']);
        }

        // Exclude specific statuses from Statement of Account (كشف الحساب)
        // Requests in statement mode should exclude: 'لم يتم السداد', 'انتظار السداد', and 'منتهي'
        if ($request->boolean('is_statement') && !in_array($contractStatus, ['not_paid', 'awaiting_transfer'])) {
            $query->where(function ($q) {
                $q->whereNull('status')
                  ->orWhere(function ($sub) {
                      $sub->whereNotIn('status', [
                          'لم يتم السداد',
                          'not_paid',
                          'unpaid',
                          'انتظار السداد',
                          'بانتظار السداد',
                          'تم انتظار حوالة مساند',
                          'بانتظار حوالة مساند',
                          'awaiting_musaned_transfer',
                          'awaiting_transfer',
                          'awaiting_payment',
                          'pending_payment',
                          'منتهي',
                          'منتهية',
                          'منتهي الصلاحية',
                          'expired',
                          'ended',
                          'terminated',
                      ])
                      ->where('status', 'not like', '%لم يتم السداد%')
                      ->where('status', 'not like', '%انتظار%')
                      ->where('status', 'not like', '%منتهي%');
                  });
            });
        }

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }
        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(function ($q) use ($s, $hideDelegateNumbers) {
                $q->where('id', 'like', "%{$s}%")
                  ->orWhere('visa_number', 'like', "%{$s}%")
                  ->orWhere('visa_holder_name', 'like', "%{$s}%")
                  ->orWhereHas('client', function ($cq) use ($s, $hideDelegateNumbers) {
                      $cq->where('name', 'like', "%{$s}%");
                      if (! $hideDelegateNumbers) {
                          $cq->orWhere('phone', 'like', "%{$s}%");
                      }
                  })
                  ->orWhereHas('employee', function ($eq) use ($s) {
                      $eq->where('name', 'like', "%{$s}%");
                  });
            });
        }

        $orders = $query->latest()->get();

        $statusSettings = \App\Models\Setting::where('group', 'order_status')->get();
        $statusLabelMap = $statusSettings->mapWithKeys(function ($item) {
            return [$item->key => $item->label];
        })->toArray();
        $statusColorMap = $statusSettings->mapWithKeys(function ($item) {
            return [$item->key => $item->color ?? '#6c757d'];
        })->toArray();

        $totalContractValue = 0;
        $totalCollected = 0;
        $totalOutstanding = 0;

        $financialOrders = $orders->map(function ($order) use (&$totalContractValue, &$totalCollected, &$totalOutstanding, $statusLabelMap, $statusColorMap, $hideDelegateNumbers) {
            $price = (float) ($order->total_price ?? 0);
            $paid = (float) ($order->musaned_paid ?? 0);
            $remaining = max(0, $price - $paid);

            $totalContractValue += $price;
            $totalCollected += $paid;
            $totalOutstanding += $remaining;

            $rawStatus = $order->status ?: 'غير محدد';
            $statusLabel = $statusLabelMap[$rawStatus] ?? $rawStatus;
            $statusColor = $statusColorMap[$rawStatus] ?? ($statusColorMap[$statusLabel] ?? '#6c757d');

            $paymentStatus = "غير محصل";
            if ($paid >= $price && $price > 0) {
                $paymentStatus = "محصل بالكامل";
            } else if ($paid > 0) {
                $paymentStatus = "محصل جزئياً";
            }

            $latestTx = $order->transactions?->sortByDesc('created_at')->first();
            $latestTxTime = $latestTx ? $latestTx->created_at->format('Y-m-d H:i') : '-';

            return [
                'id' => $order->id,
                'visa_number' => $order->visa_number ?: '-',
                'client_id' => $order->client_id,
                'client_name' => $order->client ? $order->client->name : ($order->visa_holder_name ?: '-'),
                'client_phone' => $hideDelegateNumbers
                    ? null
                    : ($order->client ? $order->client->phone : ($order->visa_holder_phone ?: '-')),
                'saudi_office_id' => $order->saudi_office_id,
                'saudi_office_name' => $order->saudiOffice ? $order->saudiOffice->name : '-',
                'external_office_id' => $order->external_office_id,
                'external_office_name' => $order->externalOffice ? $order->externalOffice->name : '-',
                'nationality' => $order->nationality ?: '-',
                'order_status' => $statusLabel,
                'order_status_raw' => $rawStatus,
                'order_status_color' => $statusColor,
                'employee_id' => $order->employee_id,
                'employee_name' => $order->employee ? $order->employee->name : '-',
                'total_price' => $price,
                'paid_amount' => $paid,
                'remaining_amount' => $remaining,
                'payment_status' => $paymentStatus,
                'latest_transaction_time' => $latestTxTime,
                'created_at' => $order->created_at ? $order->created_at->format('Y-m-d') : '-',
            ];
        });

        // Grouping for Clients Summary
        $clientIds = $orders->pluck('client_id')->filter()->unique();
        if ($request->filled('client_id')) {
            $clientIds->push((int) $request->client_id);
            $clientIds = $clientIds->unique();
        }
        $clientsWithBalance = \App\Models\Client::whereIn('id', $clientIds)
            ->pluck('opening_balance', 'id')
            ->toArray();

        $clientsMap = [];
        foreach ($financialOrders as $ord) {
            $cKey = $ord['client_id'] ? 'id_' . $ord['client_id'] : 'name_' . $ord['client_name'];
            if (!isset($clientsMap[$cKey])) {
                $cOpening = (float) ($ord['client_id'] ? ($clientsWithBalance[$ord['client_id']] ?? 0) : 0);
                $clientsMap[$cKey] = [
                    'client_id' => $ord['client_id'],
                    'client_name' => $ord['client_name'],
                    'client_phone' => $ord['client_phone'],
                    'opening_balance' => $cOpening,
                    'orders_count' => 0,
                    'total_contract_value' => 0,
                    'total_collected' => 0,
                    'total_outstanding' => 0,
                    'orders' => [],
                ];
            }
            $clientsMap[$cKey]['orders_count']++;
            $clientsMap[$cKey]['total_contract_value'] += $ord['total_price'];
            $clientsMap[$cKey]['total_collected'] += $ord['paid_amount'];
            $clientsMap[$cKey]['orders'][] = $ord;
        }

        // If a specific client is requested, ensure they appear in clientsMap even if they have 0 matching orders
        if ($request->filled('client_id')) {
            $cId = (int) $request->client_id;
            $cKey = 'id_' . $cId;
            if (!isset($clientsMap[$cKey])) {
                $cModel = \App\Models\Client::find($cId);
                if ($cModel) {
                    $openingBal = (float) ($cModel->opening_balance ?? 0);
                    $clientsMap[$cKey] = [
                        'client_id' => $cModel->id,
                        'client_name' => $cModel->name,
                        'client_phone' => $hideDelegateNumbers ? null : $cModel->phone,
                        'opening_balance' => $openingBal,
                        'orders_count' => 0,
                        'total_contract_value' => 0,
                        'total_collected' => 0,
                        'total_outstanding' => $openingBal,
                        'orders' => [],
                    ];
                }
            }
        }

        $clientsSummary = array_values(array_map(function ($c) {
            $cPrice = $c['total_contract_value'];
            $cOpening = $c['opening_balance'] ?? 0;
            $cDue = $cPrice + $cOpening;
            $cPaid = $c['total_collected'];
            $cRemaining = max(0, $cDue - $cPaid);

            $c['total_due'] = $cDue;
            $c['total_outstanding'] = $cRemaining;

            $cStatus = "غير محصل";
            if ($cPaid >= $cDue && $cDue > 0) {
                $cStatus = "محصل بالكامل";
            } else if ($cPaid > 0) {
                $cStatus = "محصل جزئياً";
            }
            $c['payment_status'] = $cStatus;
            $c['collection_rate'] = $cDue > 0 ? round(($cPaid / $cDue) * 100, 1) : 0;
            return $c;
        }, $clientsMap));

        // Grouping for Marketers Summary & Detailed
        $marketersMap = [];
        foreach ($financialOrders as $ord) {
            $mKey = $ord['employee_id'] ? 'id_' . $ord['employee_id'] : 'name_' . $ord['employee_name'];
            if (!isset($marketersMap[$mKey])) {
                $marketersMap[$mKey] = [
                    'employee_id' => $ord['employee_id'],
                    'employee_name' => $ord['employee_name'] !== '-' ? $ord['employee_name'] : 'بدون مسوق',
                    'office_name' => $ord['saudi_office_name'],
                    'orders_count' => 0,
                    'total_contract_value' => 0,
                    'total_collected' => 0,
                    'total_outstanding' => 0,
                    'orders' => [],
                    'clients_map' => [],
                ];
            }
            $marketersMap[$mKey]['orders_count']++;
            $marketersMap[$mKey]['total_contract_value'] += $ord['total_price'];
            $marketersMap[$mKey]['total_collected'] += $ord['paid_amount'];
            $marketersMap[$mKey]['total_outstanding'] += $ord['remaining_amount'];
            $marketersMap[$mKey]['orders'][] = $ord;

            $cSubKey = $ord['client_id'] ? 'id_' . $ord['client_id'] : 'name_' . $ord['client_name'];
            if (!isset($marketersMap[$mKey]['clients_map'][$cSubKey])) {
                $cSubOpening = (float) ($ord['client_id'] ? ($clientsWithBalance[$ord['client_id']] ?? 0) : 0);
                $marketersMap[$mKey]['clients_map'][$cSubKey] = [
                    'client_id' => $ord['client_id'],
                    'client_name' => $ord['client_name'],
                    'client_phone' => $ord['client_phone'],
                    'opening_balance' => $cSubOpening,
                    'orders_count' => 0,
                    'total_contract_value' => 0,
                    'total_collected' => 0,
                    'total_outstanding' => 0,
                    'orders' => [],
                ];
            }
            $marketersMap[$mKey]['clients_map'][$cSubKey]['orders_count']++;
            $marketersMap[$mKey]['clients_map'][$cSubKey]['total_contract_value'] += $ord['total_price'];
            $marketersMap[$mKey]['clients_map'][$cSubKey]['total_collected'] += $ord['paid_amount'];
            $marketersMap[$mKey]['clients_map'][$cSubKey]['total_outstanding'] += $ord['remaining_amount'];
            $marketersMap[$mKey]['clients_map'][$cSubKey]['orders'][] = $ord;
        }

        $marketersSummary = array_values(array_map(function ($m) {
            $mPrice = $m['total_contract_value'];
            $mPaid = $m['total_collected'];
            $mStatus = "غير محصل";
            if ($mPaid >= $mPrice && $mPrice > 0) {
                $mStatus = "محصل بالكامل";
            } else if ($mPaid > 0) {
                $mStatus = "محصل جزئياً";
            }
            $m['payment_status'] = $mStatus;
            $m['collection_rate'] = $mPrice > 0 ? round(($mPaid / $mPrice) * 100, 1) : 0;
            $m['clients_count'] = count($m['clients_map']);

            // Enrich marketer client maps with opening balance & total due
            $mClients = array_values(array_map(function($cSub) {
                $cSubPrice = $cSub['total_contract_value'];
                $cSubOpening = $cSub['opening_balance'] ?? 0;
                $cSubDue = $cSubPrice + $cSubOpening;
                $cSubPaid = $cSub['total_collected'];
                $cSub['total_due'] = $cSubDue;
                $cSub['total_outstanding'] = max(0, $cSubDue - $cSubPaid);
                $cSubStatus = "غير محصل";
                if ($cSubPaid >= $cSubDue && $cSubDue > 0) {
                    $cSubStatus = "محصل بالكامل";
                } else if ($cSubPaid > 0) {
                    $cSubStatus = "محصل جزئياً";
                }
                $cSub['payment_status'] = $cSubStatus;
                $cSub['collection_rate'] = $cSubDue > 0 ? round(($cSubPaid / $cSubDue) * 100, 1) : 0;
                return $cSub;
            }, $m['clients_map']));

            $m['clients'] = $mClients;
            unset($m['clients_map']);
            return $m;
        }, $marketersMap));

        if ($request->filled('client_id')) {
            $cId = (int) $request->client_id;
            $cModel = \App\Models\Client::find($cId);
            $cOpening = $cModel ? (float) ($cModel->opening_balance ?? 0) : 0;
            $totalContractValue += $cOpening;
            $totalOutstanding = max(0, $totalContractValue - $totalCollected);
        }

        $collectionRate = $totalContractValue > 0 ? round(($totalCollected / $totalContractValue) * 100, 1) : 0;

        return response()->json([
            'kpis' => [
                'total_contract_value' => $totalContractValue,
                'total_collected' => $totalCollected,
                'total_outstanding' => $totalOutstanding,
                'collection_rate' => $collectionRate,
                'total_orders' => count($financialOrders),
                'total_clients' => count($clientsSummary),
                'total_marketers' => count($marketersSummary),
            ],
            'orders' => $financialOrders,
            'clients_summary' => $clientsSummary,
            'marketers_summary' => $marketersSummary,
            'clients' => \App\Models\Client::select('id', 'name', 'phone', 'opening_balance')
                ->orderBy('name')
                ->get()
                ->map(fn($client) => [
                    'id' => $client->id,
                    'name' => $client->name,
                    'phone' => $hideDelegateNumbers ? null : $client->phone,
                    'opening_balance' => (float) ($client->opening_balance ?? 0),
                ]),
            'employees' => \App\Models\Employee::select('id', 'name', 'username')
                ->orderBy('name')
                ->get()
                ->map(function ($e) {
                    return [
                        'id' => $e->id,
                        'name' => $e->name ?: ($e->username ?: "موظف #{$e->id}"),
                    ];
                }),
        ]);
    }

    public function employeesPerformance(Request $request)
    {
        $dateFrom = $request->input('date_from');
        $dateTo = $request->input('date_to');
        $saudiOfficeId = $request->input('saudi_office_id');

        // Query total orders within period and office filter
        $ordersQuery = Order::query();
        if ($dateFrom) {
            $ordersQuery->whereDate('created_at', '>=', $dateFrom);
        }
        if ($dateTo) {
            $ordersQuery->whereDate('created_at', '<=', $dateTo);
        }
        if ($saudiOfficeId) {
            $ordersQuery->where('saudi_office_id', $saudiOfficeId);
        }

        $totalPeriodOrders = (int) $ordersQuery->count();
        $totalPeriodSales = (float) $ordersQuery->sum('total_price');

        // Fetch employees with filtered orders relationship
        $employeesQuery = \App\Models\Employee::with(['saudiOffice', 'orders' => function ($q) use ($dateFrom, $dateTo, $saudiOfficeId) {
            $q->with(['client', 'saudiOffice', 'externalOffice']);
            if ($dateFrom) {
                $q->whereDate('created_at', '>=', $dateFrom);
            }
            if ($dateTo) {
                $q->whereDate('created_at', '<=', $dateTo);
            }
            if ($saudiOfficeId) {
                $q->where('saudi_office_id', $saudiOfficeId);
            }
        }]);

        if ($saudiOfficeId) {
            $employeesQuery->where(function ($q) use ($saudiOfficeId) {
                $q->where('saudi_office_id', $saudiOfficeId)
                  ->orWhereHas('orders', function ($oq) use ($saudiOfficeId) {
                      $oq->where('saudi_office_id', $saudiOfficeId);
                  });
            });
        }

        $employees = $employeesQuery->get()->map(function ($emp) use ($totalPeriodOrders, $totalPeriodSales) {
            $empOrders = $emp->orders;
            $totalOrders = $empOrders->count();
            $completedOrders = $empOrders->whereIn('status', ['completed', 'مكتمل'])->count();
            $activeOrders = $empOrders->whereNotIn('status', ['completed', 'cancelled', 'مكتمل', 'ملغي'])->count();
            $totalSales = (float) $empOrders->sum('total_price');

            $completionRate = $totalOrders > 0 ? round(($completedOrders / $totalOrders) * 100, 1) : 0;
            $ordersSharePercentage = $totalPeriodOrders > 0 ? round(($totalOrders / $totalPeriodOrders) * 100, 1) : 0;
            $salesSharePercentage = $totalPeriodSales > 0 ? round(($totalSales / $totalPeriodSales) * 100, 1) : 0;

            $ordersList = $empOrders->map(function ($order) {
                return [
                    'id' => $order->id,
                    'visa_number' => $order->visa_number ?: '-',
                    'client_name' => $order->client ? $order->client->name : ($order->visa_holder_name ?: '-'),
                    'status' => $order->status ?: 'غير محدد',
                    'service_type' => $order->service_type ?: '-',
                    'saudi_office' => $order->saudiOffice ? $order->saudiOffice->name : '-',
                    'external_office' => $order->externalOffice ? $order->externalOffice->name : '-',
                    'total_price' => (float) ($order->total_price ?? 0),
                    'created_at' => $order->created_at ? $order->created_at->format('Y-m-d') : '-',
                    'contract_date' => $order->contract_date ? \Carbon\Carbon::parse($order->contract_date)->format('Y-m-d') : ($order->created_at ? $order->created_at->format('Y-m-d') : '-'),
                ];
            })->values();

            return [
                'id' => $emp->id,
                'name' => $emp->name,
                'position' => $emp->position ?: 'موظف',
                'office_name' => $emp->saudiOffice ? $emp->saudiOffice->name : ($emp->office_name ?: '-'),
                'total_orders' => $totalOrders,
                'completed_orders' => $completedOrders,
                'active_orders' => $activeOrders,
                'total_sales' => $totalSales,
                'completion_rate' => $completionRate,
                'orders_share_percentage' => $ordersSharePercentage,
                'sales_share_percentage' => $salesSharePercentage,
                'orders' => $ordersList,
            ];
        })->sortByDesc('total_orders')->values();

        $activeEmployeesCount = $employees->where('total_orders', '>', 0)->count();

        return response()->json([
            'kpis' => [
                'total_employees' => $employees->count(),
                'active_employees' => $activeEmployeesCount,
                'total_period_orders' => $totalPeriodOrders,
                'total_period_sales' => $totalPeriodSales,
                'avg_orders_per_emp' => $employees->count() > 0 ? round($totalPeriodOrders / $employees->count(), 1) : 0,
            ],
            'employees' => $employees,
        ]);
    }
}

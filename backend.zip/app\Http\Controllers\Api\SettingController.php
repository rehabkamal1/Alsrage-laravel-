<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\UpdatePriorityLevelsRequest;
use App\Http\Requests\UpdatePassportStatusesRequest;
use App\Http\Requests\UpdateTransferStatusesRequest;
use App\Models\Setting;
use Illuminate\Http\Request;

class SettingController extends Controller
{
    public function getPriorityLevels()
    {
        $levels = Setting::where('group', 'priority_level')
            ->orderBy('sort_order')
            ->get(['id', 'key', 'label', 'color', 'sort_order', 'is_active']);

        return response()->json(['data' => $levels]);
    }

    public function getPassportStatuses()
    {
        $statuses = Setting::where('group', 'passport_status')
            ->orderBy('sort_order')
            ->get(['id', 'key', 'label', 'color', 'sort_order', 'is_active']);

        return response()->json(['data' => $statuses]);
    }

    public function getTransferStatuses()
    {
        $statuses = Setting::where('group', 'transfer_status')
            ->orderBy('sort_order')
            ->get(['id', 'key', 'label', 'color', 'sort_order', 'is_active']);

        return response()->json(['data' => $statuses]);
    }

    public function getPaymentMethods()
    {
        $methods = Setting::where('group', 'payment_method')
            ->orderBy('sort_order')
            ->get(['id', 'key', 'label', 'color', 'sort_order', 'is_active']);

        return response()->json(['data' => $methods]);
    }

    public function getBankNames()
    {
        $banks = Setting::where('group', 'bank_name')
            ->orderBy('sort_order')
            ->get(['id', 'key', 'label', 'color', 'sort_order', 'is_active']);

        return response()->json(['data' => $banks]);
    }

    public function getServiceTypes()
    {
        $types = Setting::where('group', 'service_type')
            ->orderBy('sort_order')
            ->get(['id', 'key', 'label', 'color', 'sort_order', 'is_active']);

        return response()->json(['data' => $types]);
    }

    public function getOrderStatuses()
    {
        $statuses = Setting::where('group', 'order_status')
            ->orderBy('sort_order')
            ->get(['id', 'key', 'label', 'color', 'sort_order', 'target_days', 'is_active']);

        return response()->json(['data' => $statuses]);
    }

    public function getOrderProcessStatuses()
    {
        $statuses = Setting::where('group', 'order_process_status')
            ->orderBy('sort_order')
            ->get(['id', 'key', 'label', 'color', 'sort_order', 'is_active']);

        return response()->json(['data' => $statuses]);
    }

    public function getAuthenticationStatuses()
    {
        $statuses = Setting::where('group', 'authentication_status')
            ->orderBy('sort_order')
            ->get(['id', 'key', 'label', 'color', 'sort_order', 'is_active']);

        return response()->json(['data' => $statuses]);
    }

    public function getAuthorizationStatuses()
    {
        $statuses = Setting::where('group', 'authorization_status')
            ->orderBy('sort_order')
            ->get(['id', 'key', 'label', 'color', 'sort_order', 'is_active']);

        return response()->json(['data' => $statuses]);
    }

    public function updatePriorityLevels(UpdatePriorityLevelsRequest $request)
    {
        $levels = $request->input('levels', []);

        foreach ($levels as $level) {
            Setting::updateOrCreate(
                ['group' => 'priority_level', 'key' => $level['key']],
                [
                    'label' => $level['label'],
                    'color' => $level['color'] ?? '#6c757d',
                    'sort_order' => $level['sort_order'] ?? 0,
                    'is_active' => $level['is_active'] ?? true,
                ]
            );
        }

        return response()->json(['message' => 'تم حفظ درجات الأهمية بنجاح']);
    }

    public function updatePassportStatuses(UpdatePassportStatusesRequest $request)
    {
        $statuses = $request->input('statuses', []);

        foreach ($statuses as $status) {
            Setting::updateOrCreate(
                ['group' => 'passport_status', 'key' => $status['key']],
                [
                    'label' => $status['label'],
                    'color' => $status['color'] ?? '#6c757d',
                    'sort_order' => $status['sort_order'] ?? 0,
                    'is_active' => $status['is_active'] ?? true,
                ]
            );
        }

        return response()->json(['message' => 'تم حفظ حالات ترشيح الجواز بنجاح']);
    }

    public function updateTransferStatuses(UpdateTransferStatusesRequest $request)
    {
        $statuses = $request->input('statuses', []);

        foreach ($statuses as $status) {
            Setting::updateOrCreate(
                ['group' => 'transfer_status', 'key' => $status['key']],
                [
                    'label' => $status['label'],
                    'color' => $status['color'] ?? '#6c757d',
                    'sort_order' => $status['sort_order'] ?? 0,
                    'is_active' => $status['is_active'] ?? true,
                ]
            );
        }

        return response()->json(['message' => 'تم حفظ حالات التحويل بنجاح']);
    }

    public function updatePaymentMethods(Request $request)
    {
        $methods = $request->input('methods', []);

        foreach ($methods as $method) {
            Setting::updateOrCreate(
                ['group' => 'payment_method', 'key' => $method['key']],
                [
                    'label' => $method['label'],
                    'color' => $method['color'] ?? '#6c757d',
                    'sort_order' => $method['sort_order'] ?? 0,
                    'is_active' => $method['is_active'] ?? true,
                ]
            );
        }

        return response()->json(['message' => 'تم حفظ طرق الدفع بنجاح']);
    }

    public function updateBankNames(Request $request)
    {
        $banks = $request->input('banks', []);

        foreach ($banks as $bank) {
            Setting::updateOrCreate(
                ['group' => 'bank_name', 'key' => $bank['key']],
                [
                    'label' => $bank['label'],
                    'color' => $bank['color'] ?? '#6c757d',
                    'sort_order' => $bank['sort_order'] ?? 0,
                    'is_active' => $bank['is_active'] ?? true,
                ]
            );
        }

        return response()->json(['message' => 'تم حفظ أسماء البنوك بنجاح']);
    }

    public function updateOrderStatuses(Request $request)
    {
        $statuses = $request->input('statuses', []);

        foreach ($statuses as $status) {
            Setting::updateOrCreate(
                ['group' => 'order_status', 'key' => $status['key']],
                [
                    'label' => $status['label'],
                    'color' => $status['color'] ?? '#6c757d',
                    'sort_order' => $status['sort_order'] ?? 0,
                    'target_days' => isset($status['target_days']) ? (int) $status['target_days'] : 60,
                    'is_active' => $status['is_active'] ?? true,
                ]
            );
        }

        return response()->json(['message' => 'تم حفظ حالات الطلبات بنجاح']);
    }

    public function updateOrderProcessStatuses(Request $request)
    {
        $validated = $request->validate([
            'statuses' => ['required', 'array'],
            'statuses.*.key' => ['required', 'string', 'max:255'],
            'statuses.*.label' => ['required', 'string', 'max:255'],
            'statuses.*.color' => ['nullable', 'string', 'max:20'],
            'statuses.*.sort_order' => ['nullable', 'integer'],
            'statuses.*.is_active' => ['sometimes', 'boolean'],
        ]);

        foreach ($validated['statuses'] as $status) {
            Setting::updateOrCreate(
                ['group' => 'order_process_status', 'key' => $status['key']],
                [
                    'label' => $status['label'],
                    'color' => $status['color'] ?? '#6c757d',
                    'sort_order' => $status['sort_order'] ?? 0,
                    'is_active' => $status['is_active'] ?? true,
                ]
            );
        }

        return response()->json(['message' => 'تم حفظ حالات الطلب بنجاح']);
    }

    public function deletePriorityLevel(int $id)
    {
        $setting = Setting::where('group', 'priority_level')->find($id);
        if (!$setting) {
            return response()->json(['message' => 'العنصر غير موجود'], 404);
        }
        $setting->delete();
        return response()->json(['message' => 'تم الحذف بنجاح']);
    }

    public function deletePassportStatus(int $id)
    {
        $setting = Setting::where('group', 'passport_status')->find($id);
        if (!$setting) {
            return response()->json(['message' => 'العنصر غير موجود'], 404);
        }
        $setting->delete();
        return response()->json(['message' => 'تم الحذف بنجاح']);
    }

    public function deleteTransferStatus(int $id)
    {
        $setting = Setting::where('group', 'transfer_status')->find($id);
        if (!$setting) {
            return response()->json(['message' => 'العنصر غير موجود'], 404);
        }
        $setting->delete();
        return response()->json(['message' => 'تم الحذف بنجاح']);
    }

    public function deletePaymentMethod(int $id)
    {
        $setting = Setting::where('group', 'payment_method')->find($id);
        if (!$setting) {
            return response()->json(['message' => 'العنصر غير موجود'], 404);
        }
        $setting->delete();
        return response()->json(['message' => 'تم الحذف بنجاح']);
    }

    public function deleteBankName(int $id)
    {
        $setting = Setting::where('group', 'bank_name')->find($id);
        if (!$setting) {
            return response()->json(['message' => 'العنصر غير موجود'], 404);
        }
        $setting->delete();
        return response()->json(['message' => 'تم الحذف بنجاح']);
    }

    public function updateServiceTypes(Request $request)
    {
        $types = $request->input('types', $request->input('statuses', []));

        foreach ($types as $type) {
            Setting::updateOrCreate(
                ['group' => 'service_type', 'key' => $type['key'] ?? ''],
                [
                    'label' => $type['label'] ?? '',
                    'color' => $type['color'] ?? '#6c757d',
                    'sort_order' => $type['sort_order'] ?? 0,
                    'is_active' => $type['is_active'] ?? true,
                ]
            );
        }

        return response()->json(['message' => 'تم حفظ أنواع الخدمات بنجاح']);
    }

    public function updateAuthenticationStatuses(Request $request)
    {
        $statuses = $request->input('statuses', []);

        foreach ($statuses as $status) {
            Setting::updateOrCreate(
                ['group' => 'authentication_status', 'key' => $status['key'] ?? ''],
                [
                    'label' => $status['label'] ?? '',
                    'color' => $status['color'] ?? '#6c757d',
                    'sort_order' => $status['sort_order'] ?? 0,
                    'is_active' => $status['is_active'] ?? true,
                ]
            );
        }

        return response()->json(['message' => 'تم حفظ حالات التوثيق بنجاح']);
    }

    public function updateAuthorizationStatuses(Request $request)
    {
        $statuses = $request->input('statuses', []);

        foreach ($statuses as $status) {
            Setting::updateOrCreate(
                ['group' => 'authorization_status', 'key' => $status['key'] ?? ''],
                [
                    'label' => $status['label'] ?? '',
                    'color' => $status['color'] ?? '#6c757d',
                    'sort_order' => $status['sort_order'] ?? 0,
                    'is_active' => $status['is_active'] ?? true,
                ]
            );
        }

        return response()->json(['message' => 'تم حفظ حالات التفويض بنجاح']);
    }

    public function deleteOrderStatus(int $id)
    {
        $setting = Setting::where('group', 'order_status')->find($id);
        if (!$setting) {
            return response()->json(['message' => 'العنصر غير موجود'], 404);
        }
        $setting->delete();
        return response()->json(['message' => 'تم الحذف بنجاح']);
    }

    public function deleteOrderProcessStatus(int $id)
    {
        $setting = Setting::where('group', 'order_process_status')->find($id);
        if (!$setting) {
            return response()->json(['message' => 'العنصر غير موجود'], 404);
        }
        $setting->delete();
        return response()->json(['message' => 'تم الحذف بنجاح']);
    }

    public function deleteServiceType(int $id)
    {
        $setting = Setting::where('group', 'service_type')->find($id);
        if (!$setting) {
            return response()->json(['message' => 'العنصر غير موجود'], 404);
        }
        $setting->delete();
        return response()->json(['message' => 'تم الحذف بنجاح']);
    }

    public function deleteAuthenticationStatus(int $id)
    {
        $setting = Setting::where('group', 'authentication_status')->find($id);
        if (!$setting) {
            return response()->json(['message' => 'العنصر غير موجود'], 404);
        }
        $setting->delete();
        return response()->json(['message' => 'تم الحذف بنجاح']);
    }

    public function deleteAuthorizationStatus(int $id)
    {
        $setting = Setting::where('group', 'authorization_status')->find($id);
        if (!$setting) {
            return response()->json(['message' => 'العنصر غير موجود'], 404);
        }
        $setting->delete();
        return response()->json(['message' => 'تم الحذف بنجاح']);
    }

    public function getNationalities()
    {
        $nationalities = Setting::where('group', 'nationality')
            ->orderBy('sort_order')
            ->get(['id', 'key', 'label', 'color', 'sort_order', 'is_active']);

        return response()->json(['data' => $nationalities]);
    }

    public function getProfessions()
    {
        $professions = Setting::where('group', 'profession')
            ->orderBy('sort_order')
            ->get(['id', 'key', 'label', 'color', 'sort_order', 'is_active']);

        return response()->json(['data' => $professions]);
    }

    public function getArrivalDestinations()
    {
        $destinations = Setting::where('group', 'arrival_destination')
            ->where('is_active', true)
            ->orderBy('sort_order')
            ->get(['id', 'key', 'label', 'color', 'sort_order', 'nationality_key', 'is_active']);

        return response()->json(['data' => $destinations]);
    }

    public function updateArrivalDestinations(Request $request)
    {
        $request->validate([
            'destinations' => ['required', 'array'],
            'destinations.*.key' => ['required', 'string', 'max:255'],
            'destinations.*.label' => ['required', 'string', 'max:255'],
            'destinations.*.nationality_key' => [
                'required',
                'string',
                'max:255',
                'exists:settings,key',
            ],
        ], [
            'destinations.*.nationality_key.required' => 'يجب اختيار الجنسية لجهة الوصول',
            'destinations.*.nationality_key.exists' => 'الجنسية المحددة غير موجودة في الإعدادات',
        ]);

        $destinations = $request->input('destinations', []);

        $validNationalities = Setting::where('group', 'nationality')
            ->where('is_active', true)
            ->pluck('key')
            ->all();

        foreach ($destinations as $destination) {
            if (!in_array($destination['nationality_key'], $validNationalities, true)) {
                return response()->json([
                    'message' => 'الجنسية المحددة غير موجودة في الإعدادات',
                ], 422);
            }

            Setting::updateOrCreate(
                ['group' => 'arrival_destination', 'key' => $destination['key'] ?? ''],
                [
                    'label' => $destination['label'] ?? '',
                    'color' => $destination['color'] ?? '#6c757d',
                    'sort_order' => $destination['sort_order'] ?? 0,
                    'nationality_key' => $destination['nationality_key'],
                    'is_active' => $destination['is_active'] ?? true,
                ]
            );
        }

        return response()->json(['message' => 'تم حفظ جهات القدوم بنجاح']);
    }

    public function deleteArrivalDestination(int $id)
    {
        $setting = Setting::where('group', 'arrival_destination')->find($id);
        if (!$setting) {
            return response()->json(['message' => 'العنصر غير موجود'], 404);
        }
        $setting->delete();
        return response()->json(['message' => 'تم الحذف بنجاح']);
    }

    public function updateNationalities(Request $request)
    {
        $nationalities = $request->input('nationalities', $request->input('statuses', []));

        foreach ($nationalities as $nationality) {
            Setting::updateOrCreate(
                ['group' => 'nationality', 'key' => $nationality['key'] ?? ''],
                [
                    'label' => $nationality['label'] ?? '',
                    'color' => $nationality['color'] ?? '#6c757d',
                    'sort_order' => $nationality['sort_order'] ?? 0,
                    'is_active' => $nationality['is_active'] ?? true,
                ]
            );
        }

        return response()->json(['message' => 'تم حفظ الجنسيات بنجاح']);
    }

    public function updateProfessions(Request $request)
    {
        $professions = $request->input('professions', $request->input('statuses', []));

        foreach ($professions as $profession) {
            Setting::updateOrCreate(
                ['group' => 'profession', 'key' => $profession['key'] ?? ''],
                [
                    'label' => $profession['label'] ?? '',
                    'color' => $profession['color'] ?? '#6c757d',
                    'sort_order' => $profession['sort_order'] ?? 0,
                    'is_active' => $profession['is_active'] ?? true,
                ]
            );
        }

        return response()->json(['message' => 'تم حفظ المهن بنجاح']);
    }

    public function deleteNationality(int $id)
    {
        $setting = Setting::where('group', 'nationality')->find($id);
        if (!$setting) {
            return response()->json(['message' => 'العنصر غير موجود'], 404);
        }
        $setting->delete();
        return response()->json(['message' => 'تم الحذف بنجاح']);
    }

    public function deleteProfession(int $id)
    {
        $setting = Setting::where('group', 'profession')->find($id);
        if (!$setting) {
            return response()->json(['message' => 'العنصر غير موجود'], 404);
        }
        $setting->delete();
        return response()->json(['message' => 'تم الحذف بنجاح']);
    }
}

<?php

namespace App\Http\Resources;

use App\Support\PermissionAccess;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class OrderTrackingResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'order_id' => $this->order_id,
            'workflow_status' => $this->workflow_status,
            'order_number' => $this->order?->id,
            'saudi_office_id' => $this->saudi_office_id ?? $this->order?->saudi_office_id,
            'saudi_office_name' => $this->saudiOffice?->name ?? $this->order?->saudiOffice?->name,
            'external_office_id' => $this->external_office_id ?? $this->order?->external_office_id,
            'external_office_name' => $this->externalOffice?->name ?? $this->order?->externalOffice?->name,
            'external_office_country' => $this->externalOffice?->country ?? $this->order?->externalOffice?->country,
            'visa_holder_name' => $this->order?->visa_holder_name ?? $this->order?->client?->visa_holder_name,
            'visa_number' => $this->order?->visa_number,
            'id_number' => $this->order?->id_number ?? $this->order?->client?->id_number,
            'passport_number' => $this->order?->passport_number ?? $this->order?->client?->passport_number,
            'sponsor_number' => PermissionAccess::isHiddenFor($request->user(), PermissionAccess::HIDE_DELEGATE_NUMBERS)
                ? null
                : $this->sponsor_number,
            'delegate_phone' => PermissionAccess::isHiddenFor($request->user(), PermissionAccess::HIDE_DELEGATE_NUMBERS)
                ? null
                : ($this->delegate_phone ?? $this->order?->client?->phone ?? $this->sponsor_number),
            'authorization_number' => $this->authorization_number,
            'is_authenticated' => $this->is_authenticated,
            'authentication_date' => $this->authentication_date,
            'certification_date' => $this->certification_date,
            'authentication_number' => $this->authentication_number,
            'last_action_date' => $this->last_action_date,
            'notes' => $this->notes,
            'priority_level' => $this->priority_level,
            'passport_status' => $this->passport_status,
            'transfer_status' => $this->transfer_status,
            'authentication_status' => $this->authentication_status,
            'authorization_status' => $this->authorization_status,
            'attachments' => AttachmentResource::collection($this->attachments),
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }
}

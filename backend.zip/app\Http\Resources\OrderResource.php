<?php

namespace App\Http\Resources;

use App\Support\PermissionAccess;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class OrderResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'client_id' => $this->client_id,
            'client' => new ClientResource($this->whenLoaded('client')),
            'visa_holder_name' => $this->visa_holder_name,
            'visa_holder_phone' => $this->visa_holder_phone,
            'saudi_office_id' => $this->saudi_office_id,
            'saudi_office' => new SaudiOfficeResource($this->saudiOffice),
            'external_office_id' => $this->external_office_id,
            'external_office' => new ExternalOfficeResource($this->externalOffice),
            'externalOffice' => new ExternalOfficeResource($this->externalOffice),
            'employee_id' => $this->employee_id,
            'employee_name' => $this->employee?->name,
            'employee' => $this->whenLoaded('employee'),
            'visa_number' => $this->visa_number,
            'service_type' => $this->service_type,
            'nationality' => $this->nationality,
            'arrival_destination' => $this->arrival_destination,
            'profession' => $this->profession,
            'id_number' => $this->id_number,
            'sponsor_number' => PermissionAccess::isHiddenFor($request->user(), PermissionAccess::HIDE_DELEGATE_NUMBERS)
                ? null
                : $this->sponsor_number,
            'passport_number' => $this->passport_number,
            'birth_date' => $this->birth_date,
            'musaned_contract_number' => $this->musaned_contract_number,
            'needs_musaned_contract_number' => $this->needsMusanedContractNumber(),
            'authentication_contract_number' => $this->authentication_contract_number,
            'external_agent_number' => $this->external_agent_number,
            'contract_date' => $this->contract_date,
            'passport_date' => $this->passport_date,
            'total_price' => $this->total_price,
            'musaned_paid' => $this->musaned_paid,
            'is_paid_by_office' => $this->is_paid_by_office,
            'price_difference' => $this->price_difference,
            'visa_image' => $this->visa_image,
            'contract_image' => $this->contract_image,
            'status' => $this->status,
            'order_status' => $this->order_status,
            'notes' => $this->notes,
            'tracking' => new OrderTrackingResource($this->tracking),
            'transactions' => PermissionAccess::isHiddenFor($request->user(), PermissionAccess::HIDE_TRANSACTIONS)
                ? []
                : OrderTransactionResource::collection($this->transactions),
            'attachments' => AttachmentResource::collection($this->attachments),
            'has_tracking' => $this->tracking()->exists(),
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }
}

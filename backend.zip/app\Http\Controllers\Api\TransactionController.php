<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreTransactionRequest;
use App\Http\Requests\UpdateTransactionRequest;
use App\Http\Resources\OrderTransactionResource;
use App\Models\Order;
use App\Models\Transaction;
use App\Support\PaymentMethodClassifier;
use Illuminate\Http\Request;

class TransactionController extends Controller
{
    public function index(Request $request)
    {
        $query = Transaction::with(['order.client', 'employee', 'client']);

        if ($request->has('type') && $request->type) {
            $query->where('type', $request->type);
        }

        if ($request->has('order_id') && $request->order_id) {
            $orderId = $request->order_id;
            $query->where(function ($q) use ($orderId) {
                $q->where('order_id', $orderId)
                    ->orWhere('order_ids', 'like', '%'.$orderId.'%')
                    ->orWhere('order_ids', 'like', '%"'.$orderId.'"%');
            });
        }

        if ($request->has('client_id') && $request->client_id) {
            $query->where('client_id', $request->client_id);
        }

        if ($request->has('employee_id') && $request->employee_id) {
            $query->where('employee_id', $request->employee_id);
        }

        if ($request->has('payment_method') && $request->payment_method) {
            $query->where('payment_method', $request->payment_method);
        }

        if ($request->has('bank_name') && $request->bank_name) {
            $query->where('bank_name', 'like', '%'.$request->bank_name.'%');
        }

        if ($request->has('is_reviewed') && $request->is_reviewed !== '') {
            $query->where('is_reviewed', filter_var($request->is_reviewed, FILTER_VALIDATE_BOOLEAN));
        }

        if ($request->has('search') && $request->search) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('transfer_number', 'like', "%{$search}%")
                    ->orWhereHas('order', function ($oq) use ($search) {
                        $oq->where('id', 'like', "%{$search}%")
                            ->orWhere('visa_number', 'like', "%{$search}%")
                            ->orWhere('visa_holder_name', 'like', "%{$search}%");
                    })
                    ->orWhereHas('order.client', function ($cq) use ($search) {
                        $cq->where('name', 'like', "%{$search}%")
                            ->orWhere('visa_holder_name', 'like', "%{$search}%");
                    })
                    ->orWhereHas('client', function ($cq) use ($search) {
                        $cq->where('name', 'like', "%{$search}%")
                            ->orWhere('phone', 'like', "%{$search}%");
                    });
            });
        }

        if ($request->has('from_date') && $request->from_date) {
            $query->whereDate('transfer_date', '>=', $request->from_date);
        }
        if ($request->has('to_date') && $request->to_date) {
            $query->whereDate('transfer_date', '<=', $request->to_date);
        }

        $sortField = $request->input('sort_field', 'id');
        $sortDirection = $request->input('sort_direction', 'desc');

        $allowedSortFields = ['id', 'amount', 'transfer_date', 'created_at', 'type'];
        if (! in_array($sortField, $allowedSortFields)) {
            $sortField = 'id';
        }

        $query->orderBy($sortField, $sortDirection);

        $transactions = $query->paginate((int) $request->integer('per_page', 15))->withQueryString();

        return OrderTransactionResource::collection($transactions);
    }

    public function store(StoreTransactionRequest $request)
    {
        $data = $request->validated();
        if ($request->has('order_ids') && is_array($request->order_ids) && count($request->order_ids) > 0) {
            $data['order_id'] = $request->order_ids[0];
        }
        if (! PaymentMethodClassifier::requiresBeneficiaryBank($data['payment_method'] ?? null)) {
            $data['bank_name'] = null;
        }
        $transaction = Transaction::create($data);

        $this->syncOrderPayments($transaction->order_id);

        return (new OrderTransactionResource($transaction->load(['order.client', 'employee', 'client'])))
            ->response()
            ->setStatusCode(201);
    }

    public function show(Transaction $transaction)
    {
        return new OrderTransactionResource($transaction->load(['order.client', 'employee', 'client']));
    }

    public function update(UpdateTransactionRequest $request, Transaction $transaction)
    {
        $oldOrderId = $transaction->order_id;
        $data = $request->validated();
        if ($request->has('order_ids') && is_array($request->order_ids) && count($request->order_ids) > 0) {
            $data['order_id'] = $request->order_ids[0];
        }
        if (array_key_exists('payment_method', $data)
            && ! PaymentMethodClassifier::requiresBeneficiaryBank($data['payment_method'])) {
            $data['bank_name'] = null;
        }
        $transaction->update($data);

        $this->syncOrderPayments($transaction->order_id);
        if ($oldOrderId && $oldOrderId !== $transaction->order_id) {
            $this->syncOrderPayments($oldOrderId);
        }

        return new OrderTransactionResource($transaction->load(['order.client', 'employee', 'client']));
    }

    public function destroy(Transaction $transaction)
    {
        $orderId = $transaction->order_id;
        $transaction->delete();

        if ($orderId) {
            $this->syncOrderPayments($orderId);
        }

        return response()->json([
            'message' => 'تم حذف الحوالة بنجاح.',
        ]);
    }

    private function syncOrderPayments($orderId): void
    {
        if (! $orderId) {
            return;
        }

        $order = Order::find($orderId);
        if (! $order) {
            return;
        }

        $receiptsSum = (float) Transaction::where('order_id', $orderId)
            ->where('type', 'receipt')
            ->sum('amount');

        if ($receiptsSum > 0) {
            $order->musaned_paid = $receiptsSum;
            $totalPrice = (float) ($order->total_price ?? 0);
            $order->price_difference = max(0, $totalPrice - $receiptsSum);

            if ($receiptsSum >= $totalPrice && $totalPrice > 0) {
                $order->status = 'تم السداد مساند';
            }
            $order->saveQuietly();
        }
    }

    public function summary(Request $request)
    {
        $query = Transaction::query();

        if ($request->has('from_date') && $request->from_date) {
            $query->whereDate('transfer_date', '>=', $request->from_date);
        }
        if ($request->has('to_date') && $request->to_date) {
            $query->whereDate('transfer_date', '<=', $request->to_date);
        }

        $totalReceipts = (float) $query->clone()->where('type', 'receipt')->sum('amount');
        $totalPayments = (float) $query->clone()->where('type', 'payment')->sum('amount');
        $netProfit = $totalReceipts - $totalPayments;

        return response()->json([
            'success' => true,
            'data' => [
                'total_receipts' => $totalReceipts,
                'total_payments' => $totalPayments,
                'net_profit' => $netProfit,
            ],
        ]);
    }

    public function getOrdersByClient(Request $request)
    {
        $clientId = $request->query('client_id');

        if (! $clientId) {
            return response()->json([
                'success' => false,
                'message' => 'client_id is required',
                'data' => [],
            ], 400);
        }

        $orders = Order::where('client_id', $clientId)
            ->with(['client', 'saudiOffice', 'externalOffice'])
            ->orderBy('id', 'desc')
            ->get();

        return response()->json([
            'success' => true,
            'data' => $orders,
        ]);
    }
}

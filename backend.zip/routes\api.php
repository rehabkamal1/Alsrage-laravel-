<?php

use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\ClientController;
use App\Http\Controllers\Api\ExternalOfficeController;
use App\Http\Controllers\Api\OrderController;
use App\Http\Controllers\Api\OrderTrackingController;
use App\Http\Controllers\Api\SaudiOfficeController;
use App\Http\Controllers\Api\EmployeeController;
use App\Http\Controllers\Api\TransactionController;
use App\Http\Controllers\Api\SettingController;
use App\Http\Controllers\Api\AttachmentController;
use App\Http\Controllers\Api\MarketingLeadController;
use App\Http\Controllers\Api\ReportController;
use Illuminate\Support\Facades\Route;

Route::post('/register', [AuthController::class, 'register'])->middleware('throttle:10,1');
Route::post('/login', [AuthController::class, 'login'])->middleware('throttle:10,1')->name('login');

Route::middleware('auth:sanctum')->group(function () {
    Route::post('/logout', [AuthController::class, 'logout']);
    Route::get('/me', [AuthController::class, 'me']);

    Route::get('/clients/search', [ClientController::class, 'search']);
    Route::post('/clients/quick', [ClientController::class, 'quickStore']);
    Route::apiResource('clients', ClientController::class);

    Route::apiResource('saudi-offices', SaudiOfficeController::class);
    Route::apiResource('external-offices', ExternalOfficeController::class);
    Route::apiResource('employees', EmployeeController::class);
    Route::apiResource('orders', OrderController::class)->except(['store']);
    Route::post('/orders', [OrderController::class, 'store'])
        ->middleware([\App\Http\Middleware\IdempotentSubmission::class, 'throttle:5,1'])
        ->name('orders.store');
    Route::get('/orders/without-tracking', [OrderController::class, 'getOrdersWithoutTracking']);
    Route::apiResource('order-tracking', OrderTrackingController::class);

    Route::middleware('not-hidden:hide_transactions')->group(function () {
        Route::get('/transactions/orders-by-client', [TransactionController::class, 'getOrdersByClient']);
        Route::get('/finance/summary', [TransactionController::class, 'summary']);
        Route::apiResource('transactions', TransactionController::class)->except(['store']);
        Route::post('/transactions', [TransactionController::class, 'store'])
            ->middleware([\App\Http\Middleware\IdempotentSubmission::class, 'throttle:5,1'])
            ->name('transactions.store');
        Route::get('/reports/financial-collections', [ReportController::class, 'financialCollections'])->middleware('throttle:30,1');
    });

    Route::get('/settings/priority-levels', [SettingController::class, 'getPriorityLevels']);
    Route::get('/settings/passport-statuses', [SettingController::class, 'getPassportStatuses']);
    Route::get('/settings/transfer-statuses', [SettingController::class, 'getTransferStatuses']);
    Route::get('/settings/payment-methods', [SettingController::class, 'getPaymentMethods']);
    Route::get('/settings/bank-names', [SettingController::class, 'getBankNames']);
    Route::get('/settings/order-statuses', [SettingController::class, 'getOrderStatuses']);
    Route::get('/settings/order-process-statuses', [SettingController::class, 'getOrderProcessStatuses']);
    Route::get('/settings/service-types', [SettingController::class, 'getServiceTypes']);
    Route::get('/settings/authentication-statuses', [SettingController::class, 'getAuthenticationStatuses']);
    Route::get('/settings/authorization-statuses', [SettingController::class, 'getAuthorizationStatuses']);

    Route::post('/settings/priority-levels', [SettingController::class, 'updatePriorityLevels']);
    Route::post('/settings/passport-statuses', [SettingController::class, 'updatePassportStatuses']);
    Route::post('/settings/transfer-statuses', [SettingController::class, 'updateTransferStatuses']);
    Route::post('/settings/payment-methods', [SettingController::class, 'updatePaymentMethods']);
    Route::post('/settings/bank-names', [SettingController::class, 'updateBankNames']);
    Route::post('/settings/order-statuses', [SettingController::class, 'updateOrderStatuses']);
    Route::post('/settings/order-process-statuses', [SettingController::class, 'updateOrderProcessStatuses']);
    Route::post('/settings/service-types', [SettingController::class, 'updateServiceTypes']);
    Route::post('/settings/authentication-statuses', [SettingController::class, 'updateAuthenticationStatuses']);
    Route::post('/settings/authorization-statuses', [SettingController::class, 'updateAuthorizationStatuses']);

    Route::delete('/settings/priority-levels/{id}', [SettingController::class, 'deletePriorityLevel']);
    Route::delete('/settings/passport-statuses/{id}', [SettingController::class, 'deletePassportStatus']);
    Route::delete('/settings/transfer-statuses/{id}', [SettingController::class, 'deleteTransferStatus']);
    Route::delete('/settings/payment-methods/{id}', [SettingController::class, 'deletePaymentMethod']);
    Route::delete('/settings/bank-names/{id}', [SettingController::class, 'deleteBankName']);
    Route::delete('/settings/order-statuses/{id}', [SettingController::class, 'deleteOrderStatus']);
    Route::delete('/settings/order-process-statuses/{id}', [SettingController::class, 'deleteOrderProcessStatus']);
    Route::delete('/settings/service-types/{id}', [SettingController::class, 'deleteServiceType']);
    Route::delete('/settings/authentication-statuses/{id}', [SettingController::class, 'deleteAuthenticationStatus']);
    Route::delete('/settings/authorization-statuses/{id}', [SettingController::class, 'deleteAuthorizationStatus']);

    Route::post('/order-tracking/{orderTracking}/attachments', [AttachmentController::class, 'store']);
    Route::delete('/attachments/{attachment}', [AttachmentController::class, 'destroy']);

    Route::get('/marketing-leads/saudi-offices', [MarketingLeadController::class, 'getSaudiOffices']);
    Route::get('/marketing-leads/external-offices', [MarketingLeadController::class, 'getExternalOffices']);
    Route::get('/marketing-leads/service-offices', [MarketingLeadController::class, 'getServiceOffices']);
    Route::get('/marketing-leads/statuses', [MarketingLeadController::class, 'getStatuses']);
    Route::get('/marketing-leads/priority-levels', [MarketingLeadController::class, 'getPriorityLevels']);

    Route::post('/marketing-leads/saudi-office', [MarketingLeadController::class, 'storeSaudiOffice']);
    Route::post('/marketing-leads/external-office', [MarketingLeadController::class, 'storeExternalOfficeNew']);
    Route::post('/marketing-leads/service-office', [MarketingLeadController::class, 'storeServiceOfficeNew']);

    Route::get('/settings/nationalities', [SettingController::class, 'getNationalities']);
    Route::get('/settings/professions', [SettingController::class, 'getProfessions']);
    Route::get('/settings/arrival-destinations', [SettingController::class, 'getArrivalDestinations']);

    Route::post('/settings/nationalities', [SettingController::class, 'updateNationalities']);
    Route::post('/settings/professions', [SettingController::class, 'updateProfessions']);
    Route::post('/settings/arrival-destinations', [SettingController::class, 'updateArrivalDestinations']);

    Route::delete('/settings/nationalities/{id}', [SettingController::class, 'deleteNationality']);
    Route::delete('/settings/professions/{id}', [SettingController::class, 'deleteProfession']);
    Route::delete('/settings/arrival-destinations/{id}', [SettingController::class, 'deleteArrivalDestination']);

    Route::apiResource('marketing-leads', MarketingLeadController::class);

    // Reports
    Route::get('/reports/order-follow-up', [ReportController::class, 'orderFollowUp'])->middleware('throttle:30,1');
    Route::get('/reports/completed-orders', [ReportController::class, 'completedOrders'])->middleware('throttle:30,1');
    Route::get('/reports/offices-performance', [ReportController::class, 'officesPerformance'])->middleware('throttle:30,1');
    Route::get('/reports/employees-performance', [ReportController::class, 'employeesPerformance'])->middleware('throttle:30,1');
});
